import { useState } from "react";
import { useUploadPayload } from "@/hooks/use-payloads";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { FileCode, Upload, Save, AlertCircle, Download } from "lucide-react";
import { motion } from "framer-motion";

export default function Admin() {
  const uploadPayload = useUploadPayload();
  const [content, setContent] = useState("");
  const [filename, setFilename] = useState("update.js");
  const [dragActive, setDragActive] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFilename(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result;
        if (typeof text === "string") {
          setContent(text);
        }
      };
      reader.readAsText(file);
    }
  };

  const handleSave = () => {
    if (!content.trim()) return;
    uploadPayload.mutate({ filename, jsContent: content });
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setFilename(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result;
        if (typeof text === "string") {
          setContent(text);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6 md:p-12">
      <div className="max-w-4xl mx-auto space-y-8">
        <header className="flex items-center justify-between">
          <div className="space-y-1">
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">Payload Manager</h1>
            <p className="text-slate-500">Manage the Javascript payload delivered to users.</p>
          </div>
          <div className="flex items-center space-x-2 bg-yellow-50 text-yellow-800 px-4 py-2 rounded-full border border-yellow-200 text-sm font-medium">
            <AlertCircle className="w-4 h-4" />
            <span>Admin Area</span>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-2 space-y-6"
          >
            <Card>
              <CardHeader>
                <CardTitle>Payload Content</CardTitle>
                <CardDescription>
                  Paste your JS code directly or verify the content of the uploaded file.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="filename">Target Filename</Label>
                  <Input 
                    id="filename" 
                    value={filename} 
                    onChange={(e) => setFilename(e.target.value)}
                    placeholder="update.js"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="content">JavaScript Code</Label>
                  <Textarea
                    id="content"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="font-mono text-sm min-h-[400px] bg-slate-900 text-slate-50 p-4 border-slate-800 focus-visible:ring-slate-400"
                    placeholder="// Paste your payload code here..."
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-1 space-y-6"
          >
            <Card className="bg-white">
              <CardHeader>
                <CardTitle>Actions</CardTitle>
                <CardDescription>Upload, save, and download payloads.</CardDescription>
              </CardHeader>
              <CardContent>
                <div 
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
                    dragActive 
                      ? "border-primary bg-primary/5" 
                      : "border-slate-200 hover:border-primary/50 hover:bg-slate-50"
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                  onClick={() => document.getElementById('file-upload')?.click()}
                >
                  <input
                    id="file-upload"
                    type="file"
                    accept=".js,.txt"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                  <div className="flex flex-col items-center gap-2 text-slate-500">
                    <div className="p-3 bg-slate-100 rounded-full mb-2">
                      <FileCode className="w-6 h-6 text-slate-600" />
                    </div>
                    <span className="text-sm font-medium text-slate-900">
                      Click to upload
                    </span>
                    <span className="text-xs">
                      or drag and drop .js file
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button 
              size="lg" 
              className="w-full h-12 text-base shadow-lg shadow-primary/20"
              onClick={handleSave}
              disabled={uploadPayload.isPending || !content}
            >
              {uploadPayload.isPending ? (
                "Deploying..."
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Deploy Payload
                </>
              )}
            </Button>

            <Button 
              size="lg" 
              variant="outline"
              className="w-full h-12 text-base"
              onClick={() => window.location.href = '/api/payloads/pdf'}
            >
              <Download className="w-4 h-4 mr-2" />
              Download Generated PDF
            </Button>
            
            <p className="text-xs text-center text-slate-400">
              Deploying will overwrite the current active payload immediately. PDF contains the warning text + your JS embedded.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
